# 🧠 Aplicación Flask para Análisis y Ciencia de Datos

Esta aplicación ofrece una suite visual y avanzada para explorar, analizar y predecir datos en tiempo real. Ideal para analistas, científicos de datos y proyectos de consultoría de datos.

## 🚀 Funcionalidades

- 📊 Generador de dashboards automáticos y personalizados
- 🧼 Revisión de calidad de datos para Power BI
- 🔮 Predicción automática de KPIs
- 🧠 Recomendador inteligente de filtros por clustering
- 🖼️ Comparador visual de dashboards (PDF/imagen)

## 🎨 Paleta de color corporativa AJF
- Azul: `#2c3e50`
- Fondo: `#f5f2ea`
- Secundario: `#debfb0`
- Tercero: `#7f8c8d`
- Gris oscuro: `#020202`

## 📦 Despliegue rápido con Render

1. Crear cuenta en [https://render.com](https://render.com)
2. Conectar este repositorio
3. Configurar:
   - Build: `pip install -r requirements.txt`
   - Start: `python run.py`
   - Root directory: `.`

## 🌐 Integración con GitHub Pages

Puedes embeber esta app en tu web con este iframe:

```html
<iframe 
  src="https://TU-APP-RENDER.onrender.com" 
  width="100%" 
  height="860px" 
  style="border:1px solid #2c3e50; border-radius:1rem;">
</iframe>
```

## 📁 Estructura

```
app/
├── templates/
├── utils/
├── static/
├── routes.py
├── run.py
├── requirements.txt
```
